from django.shortcuts import render

# Create your views here.


def index(request):
    return render(request, "fath/all_products.html")


def cart(request):
    return render(request, "cart/cart.html")
